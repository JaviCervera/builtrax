
function EventListener(){
}

EventListener.prototype.handleEvent=function(e){
}
